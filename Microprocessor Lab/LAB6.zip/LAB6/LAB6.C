#include <at89c5131.h>
#include "lcd.h"
int arr[5];
int i;
int j;
int swapper;
int find;


code unsigned char display_msg1[]=" START PROGRAM  ";						//Display msg on 1st line of lcd
code unsigned char display_msg2[]="  FIRST INPUT   ";						//Display msg on 1st line of lcd
code unsigned char display_msg3[]="   NEXT INPUT   ";						//Display msg on 1st line of lcd
code unsigned char display_msg4[]="   SORTING...   ";						//Display msg on 1st line of lcd
code unsigned char display_msg5[]="     SORTING    ";						//Display msg on 1st line of lcd
code unsigned char display_msg6[]="    COMPLETED   ";						//Display msg on 1st line of lcd
code unsigned char display_msg7[]="  NUMBER TO BE  ";						//Display msg on 1st line of lcd
code unsigned char display_msg8[]="    SEARCHED    ";						//Display msg on 2nd line of lcd
code unsigned char display_msg9[]="  THE INDEX IS  ";						//Display msg on 1st line of lcd
code unsigned char display_msg10[]="     NUMBER     ";						//Display msg on 1st line of lcd
code unsigned char display_msg11[]="   NOT FOUND    ";					//Display msg on 2nd line of lcd




void main()
{
	lcd_init();
	lcd_cmd(0x80);
	msdelay(4);
	lcd_write_string(display_msg1); //starting
	P1 = 0x0F; //leds off and sws on
	msdelay(5000); 
	lcd_cmd(0x01);
	msdelay(4);
	
	//WRITING AND READING INPUTS
	lcd_write_string(display_msg2); //write input1
	msdelay(5000);
	arr[0]=P1;//read input1 and store in array
	P1 = (((P1 & 0xF0) >> 4) | ((P1 & 0x0F) << 4)) | 0x0F;//display it for 5s on leds
	//P1 =  P1 | 0x0F;
	lcd_cmd(0x01);
	msdelay(4);
	
	lcd_write_string(display_msg3); //write input2
	msdelay(5000);
	P1 = 0x0F;//leds off for 1s after displaying input1
	msdelay(1000);
	arr[1]=(P1 & 0x0F);//read input2 and store in array
	P1 = (((P1 & 0xF0) >> 4) | ((P1 & 0x0F) << 4))| 0x0F;//display it for 5s on leds
	//P1 =  P1 | 0x0F;
	lcd_cmd(0x01);
	msdelay(4);
	
	lcd_write_string(display_msg3); //write input3
	msdelay(5000);
	P1 = 0x0F;//leds off for 1s after displaying input2
	msdelay(1000);
	arr[2]=(P1 & 0x0F);//read input and store in array
	P1 = (((P1 & 0xF0) >> 4) | ((P1 & 0x0F) << 4))| 0x0F;//display it for 5s on leds
	//P1 =  P1 | 0x0F;
	lcd_cmd(0x01);
	msdelay(4);
	
	lcd_write_string(display_msg3); //write input4
	msdelay(5000);
	P1 = 0x0F;//leds off for 1s after displaying input3
	msdelay(1000);
	arr[3]=(P1 & 0x0F);//read input and store in array
	P1 = (((P1 & 0xF0) >> 4) | ((P1 & 0x0F) << 4))| 0x0F;//display it for 5s on leds
	//P1 =  P1 | 0x0F;
	lcd_cmd(0x01);
	msdelay(4);
	
	lcd_write_string(display_msg3); //write input5
	msdelay(5000);	
	P1 = 0x0F;//leds off for 1s after displaying input4
	msdelay(1000);
	arr[4]=(P1 & 0x0F);//read input and store in array
	P1 = (((P1 & 0xF0) >> 4) | ((P1 & 0x0F) << 4))| 0x0F;//display it for 5s on leds
	//P1 =  P1 | 0x0F;
	lcd_cmd(0x01);
	msdelay(4);
	
	lcd_write_string(display_msg4); //sorting.. when last input is displayed
	msdelay(5000);	
	lcd_cmd(0x01);
	msdelay(4);
	P1 = 0x00;
	msdelay(1000);
	
	//SORTING ALGORITHM
	//bubble sort
	for(i = 0; i < 5; i++) {
    for(j = 0; j < 4-i; j++) {
     if(arr[j] > arr[j+1]) { 
         swapper = arr[j];
	  		 arr[j] = arr[j+1];
         arr[j+1] = swapper; // Swap
      }
     }
   }
	lcd_write_string(display_msg5);
	lcd_cmd(0xC0);													//Move cursor to 2nd line of LCD
	msdelay(4);
	lcd_write_string(display_msg6);
	 msdelay(4);
	
	//DISPLAYING SORTED ARRAY ON LEDS
	P1 = 0x00;
	//P1 = arr[0];
	P1 = ((arr[0] & 0xF0) >> 4) | ((arr[0] & 0x0F) << 4);//for storing it in led section swapped
	msdelay(5000);
	P1 = 0x00;
	msdelay(1000);
		
	//P1 = arr[1];
	P1 = ((arr[1] & 0xF0) >> 4) | ((arr[1] & 0x0F) << 4);
	msdelay(5000);
	P1 = 0x00;
	msdelay(1000);
		
	//P1 = arr[2];
	P1 = ((arr[2] & 0xF0) >> 4) | ((arr[2] & 0x0F) << 4);
	msdelay(5000);
	P1 = 0x00;
	msdelay(1000);
		
	//P1 = arr[3];
	P1 = ((arr[3] & 0xF0) >> 4) | ((arr[3] & 0x0F) << 4);
	msdelay(5000);
	P1 = 0x00;
	msdelay(1000);
	
	//P1 = arr[4];
	P1 = ((arr[4] & 0xF0) >> 4) | ((arr[4] & 0x0F) << 4);
	msdelay(5000);
	P1 = 0x00;	
	msdelay(1000);
		
	//READING INPUT TO  BE SEARCHED
	P1 = 0xFF;
	lcd_cmd(0x80);
	lcd_write_string(display_msg7);
	lcd_cmd(0xC0);													//Move cursor to 2nd line of LCD
	msdelay(4);
	lcd_write_string(display_msg8);
	msdelay(5000);
	find = P1 & 0x0F;
	P1 = 0x00;
	lcd_cmd(0x01);
	msdelay(1000);
	
	//SEARCH ALGORITHM
	if((find==arr[0])){
		lcd_write_string(display_msg9);
		P1 = 0x10;
		msdelay(5000);
	} else if((find==arr[1])){
	lcd_write_string(display_msg9);
		P1 = 0x20;
		msdelay(5000);}
	else if((find==arr[2])){
	lcd_write_string(display_msg9);
		P1 = 0x30;
		msdelay(5000);}
	else if((find==arr[3])){
	lcd_write_string(display_msg9);
		P1 = 0x40;
		msdelay(5000);}
	else if((find==arr[4])){
	lcd_write_string(display_msg9);
		P1 = 0x50;
		msdelay(5000);}
	else {
		P1 = 0xF0;
		lcd_write_string(display_msg10);
		lcd_cmd(0xC0);													//Move cursor to 2nd line of LCD
		msdelay(4);
		lcd_write_string(display_msg11);
		msdelay(5000);
	}
	
	while(1);
}