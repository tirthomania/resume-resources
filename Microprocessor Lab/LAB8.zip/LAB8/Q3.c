#include <stdio.h>
#include <at89c5131.h>
#include "lcd.h"

int sec=0;
int min=0;	
char str[6];

void timer0_isr(void) interrupt 1
	{
		TH0=0xFF;
	  TL0=0xC4;
    sec++ ;               
    if(sec==60){min ++;
			          sec = 0;}
		lcd_cmd(0x80);
		sprintf(str, "%02d:%02d", min, sec);									
    lcd_write_string(str);								
  }




void main(){
	lcd_init();
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string("00:00");
  EA = 1; // Enable global interrupts
	ET0 = 1;
	P1= 0x0F;
	TMOD = 0x05;
	TH0=0xFF;
	TL0= 0xC4;
	P3_4=1;
	while(1){
		        if (P1_0 == 1){
							             TR0=1;
						              }
						else {TR0=0;}
												
	}
}